#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

@interface SedaController : UIViewController <WKScriptMessageHandler,WKNavigationDelegate,UIDocumentPickerDelegate>
@property(nonatomic,strong) WKWebView *web;
@property(nonatomic,strong) NSURL *pendingROM;
@end
@implementation SedaController
- (NSURL *)storage {
 NSURL *docs=[NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject;
 NSURL *directory=[docs URLByAppendingPathComponent:@"SedaData" isDirectory:YES];
 [NSFileManager.defaultManager createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:nil error:nil]; return directory;
}
- (void)loadView {
 WKWebViewConfiguration *config=[WKWebViewConfiguration new];
 [config.userContentController addScriptMessageHandler:self name:@"seda"];
 self.web=[[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
 self.web.navigationDelegate=self; self.web.scrollView.bounces=NO;
 self.web.opaque=NO; self.web.backgroundColor=[UIColor colorWithRed:0.957 green:0.945 blue:0.914 alpha:1];
 self.view=self.web;
 NSURL *root=[NSBundle.mainBundle.resourceURL URLByAppendingPathComponent:@"web" isDirectory:YES];
 [self.web loadFileURL:[root URLByAppendingPathComponent:@"index.html"] allowingReadAccessToURL:root];
}
- (void)reply:(NSNumber *)identifier value:(id)value success:(BOOL)success {
 NSArray *args=@[identifier ?: @0,value ?: NSNull.null,@(success)];
 NSData *data=[NSJSONSerialization dataWithJSONObject:args options:0 error:nil];
 NSString *json=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
 [self.web evaluateJavaScript:[NSString stringWithFormat:@"window.SedaNativeReply.apply(null,%@)",json] completionHandler:nil];
}
- (void)userContentController:(WKUserContentController *)controller didReceiveScriptMessage:(WKScriptMessage *)message {
 if(![message.body isKindOfClass:NSDictionary.class])return;
 NSDictionary *body=message.body; NSString *action=body[@"action"]; NSNumber *identifier=body[@"id"];
 if([action isEqual:@"pick"]) {
  UIDocumentPickerViewController *picker=[[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
  picker.delegate=self; [self presentViewController:picker animated:YES completion:nil]; return;
 }
 if([action isEqual:@"clear"]) {
  NSError *error=nil; [NSFileManager.defaultManager removeItemAtURL:[self storage] error:&error];
  [self reply:identifier value:nil success:!error]; return;
 }
 NSString *key=body[@"key"];
 if(![key isKindOfClass:NSString.class] || key.length>100 || ![key rangeOfString:@"^(last-rom|save-[0-9]+-[a-f0-9]+)$" options:NSRegularExpressionSearch].length){[self reply:identifier value:nil success:NO];return;}
 NSURL *file=[[self storage] URLByAppendingPathComponent:[key stringByAppendingString:@".json"]];
 if([action isEqual:@"read"]) {
  NSData *data=[NSData dataWithContentsOfURL:file];
  id value=data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:nil] : nil;
  [self reply:identifier value:value success:YES];
 } else if([action isEqual:@"write"] && [body[@"value"] isKindOfClass:NSDictionary.class]) {
  NSData *data=[NSJSONSerialization dataWithJSONObject:body[@"value"] options:0 error:nil];
  BOOL ok=data && data.length<16000000 && [data writeToURL:file atomically:YES];
  [self reply:identifier value:nil success:ok];
 }
}
- (void)openROM:(NSURL *)url {
 if(!self.isViewLoaded){self.pendingROM=url;return;}
 BOOL scoped=[url startAccessingSecurityScopedResource];
 NSData *data=[NSData dataWithContentsOfURL:url options:NSDataReadingMappedIfSafe error:nil];
 if(scoped)[url stopAccessingSecurityScopedResource];
 if(!data || data.length<32768 || data.length>8389120){
  UIAlertController *alert=[UIAlertController alertControllerWithTitle:@"No pude abrir el ROM" message:@"Elige un archivo SNES .sfc o .smc descomprimido, de hasta 8 MB." preferredStyle:UIAlertControllerStyleAlert];
  [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
  [self presentViewController:alert animated:YES completion:nil];return;
 }
 NSArray *args=@[[data base64EncodedStringWithOptions:0],url.lastPathComponent];
 NSData *json=[NSJSONSerialization dataWithJSONObject:args options:0 error:nil];
 NSString *js=[NSString stringWithFormat:@"window.SedaOpenNativeROM.apply(null,%@)",[[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding]];
 [self.web evaluateJavaScript:js completionHandler:^(id result,NSError *error){if(error)self.pendingROM=url;}];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
 if(urls.count)[self openROM:urls.firstObject];
}
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
 if(self.pendingROM){NSURL *url=self.pendingROM; self.pendingROM=nil;[self openROM:url];}
}
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {[webView reload];}
- (BOOL)prefersStatusBarHidden{return YES;}
@end
@interface SedaDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) SedaController *controller;
@end
@implementation SedaDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)options {
 self.window=[[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];self.controller=[SedaController new];self.window.rootViewController=self.controller;[self.window makeKeyAndVisible];return YES;
}
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {[self.controller openROM:url];return YES;}
@end
int main(int argc,char *argv[]){@autoreleasepool{return UIApplicationMain(argc,argv,nil,NSStringFromClass(SedaDelegate.class));}}
