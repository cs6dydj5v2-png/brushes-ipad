/* Seda frontend. ES5 syntax and APIs available in Safari 12. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var core, ready = false, loaded = false, running = false, demo = false;
  var rom = null, gameName = '', gameKey = '', db = null, saved = null;
  var canvas = $('game-canvas'), context = canvas.getContext('2d'), image = context.createImageData(512, 448);
  var audio = null, gain = null, audioNext = 0, sound = false;
  var frameHandle = 0, frameCounter = 0, lastFrame = 0, perfStart = 0, perfFrames = 0;
  var inputs = {}, keyboard = {}, padMask = 0, lastTouch = 0, toastTimer;
  var bits = {up:2048,down:1024,left:512,right:256,a:128,b:32768,x:64,y:16384,l:32,r:16,start:4096,select:8192};
  var keys = {ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',KeyZ:'b',KeyX:'a',KeyA:'y',KeyS:'x',KeyQ:'l',KeyW:'r',Enter:'start',ShiftLeft:'select',ShiftRight:'select'};
  var keyCodes = {37:'left',38:'up',39:'right',40:'down',90:'b',88:'a',65:'y',83:'x',81:'l',87:'r',13:'start',16:'select'};

  function status(message, error) {
    $('status').textContent = message;
    $('status').style.color = error ? '#a14b36' : '';
  }
  function toast(message) {
    clearTimeout(toastTimer);
    $('toast').textContent = message;
    $('toast').hidden = false;
    toastTimer = setTimeout(function () { $('toast').hidden = true; }, 3200);
  }
  function height() { document.documentElement.style.setProperty('--app-height', window.innerHeight + 'px'); }
  height();
  window.addEventListener('resize', height);

  var nativeCallbacks = {}, nativeSequence = 0;
  function nativeAvailable() { return !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.seda); }
  function nativeRequest(action, key, value, callback) {
    var id = ++nativeSequence;
    nativeCallbacks[id] = callback;
    window.webkit.messageHandlers.seda.postMessage({id:id,action:action,key:key,value:value || null});
  }
  function encodeBytes(buffer) {
    var bytes=new Uint8Array(buffer), parts=[];
    for(var i=0;i<bytes.length;i+=8192) { parts.push(String.fromCharCode.apply(null,bytes.subarray(i,i+8192))); }
    return btoa(parts.join(''));
  }
  function decodeBytes(encoded) { var text=atob(encoded), bytes=new Uint8Array(text.length); for(var i=0;i<text.length;i++){bytes[i]=text.charCodeAt(i);} return bytes.buffer; }
  window.SedaNativeReply = function(id,value,ok) {
    var callback=nativeCallbacks[id]; delete nativeCallbacks[id];
    if(callback) { callback(value,ok); }
  };
  window.SedaOpenNativeROM = function(encoded,name) {
    try { prepare(decodeBytes(encoded),name,false,false); } catch(e) { status(e.message,true); }
  };
  var nativeLabel=document.querySelector('label[for="rom-input"]');
  if(nativeLabel) { nativeLabel.addEventListener('click',function(event){ if(nativeAvailable()){event.preventDefault(); nativeRequest('pick',null,null,function(){});} }); }
  function openDatabase() {
    if(nativeAvailable()) {
      getRecord('last-rom',function(record){ if(record && !rom && !loaded){prepare(record.bytes,record.name,false,true);} });
      return;
    }
    if (!window.indexedDB) { return; }
    try {
      var request = indexedDB.open('seda-local', 1);
      request.onupgradeneeded = function (event) { event.target.result.createObjectStore('data'); };
      request.onsuccess = function () {
        db = request.result;
        db.onversionchange = function () { db.close(); db = null; };
        getRecord('last-rom', function (record) {
          if (record && !rom && !loaded) {
            try { prepare(record.bytes, record.name, false, true); } catch (e) { status('No se pudo recuperar el ROM. Puedes abrirlo otra vez.', true); }
          }
        });
      };
      request.onerror = function () { db = null; };
    } catch (e) { db = null; }
  }
  function getRecord(key, callback) {
    if(nativeAvailable()) { nativeRequest('read',key,null,function(value,ok){
      if(ok && value && value.bytes){try{value.bytes=decodeBytes(value.bytes);}catch(e){value=null;}}
      callback(ok ? value : null);
    }); return; }
    if (!db) { callback(null); return; }
    try {
      var request = db.transaction('data').objectStore('data').get(key);
      request.onsuccess = function () { callback(request.result || null); };
      request.onerror = function () { callback(null); };
    } catch (e) { callback(null); }
  }
  function putRecord(key, value, callback) {
    if(nativeAvailable()) {
      var packed={}, k; for(k in value){if(Object.prototype.hasOwnProperty.call(value,k)){packed[k]=k==='bytes' ? encodeBytes(value[k]) : value[k];}}
      nativeRequest('write',key,packed,function(value,ok){if(callback){callback(ok);}}); return;
    }
    if (!db) { if (callback) { callback(false); } return; }
    try {
      var tx = db.transaction('data', 'readwrite');
      tx.objectStore('data').put(value, key);
      tx.oncomplete = function () { if (callback) { callback(true); } };
      tx.onerror = tx.onabort = function () { if (callback) { callback(false); } };
    } catch (e) { if (callback) { callback(false); } }
  }
  function fingerprint(bytes) {
    var hash = 2166136261;
    for (var i = 0; i < bytes.length; i++) { hash = Math.imul(hash ^ bytes[i], 16777619); }
    return bytes.length + '-' + (hash >>> 0).toString(16);
  }
  function validate(bytes) {
    if (bytes.length < 32768 || bytes.length > 8389120) { throw new Error('El ROM debe ocupar entre 32 KB y 8 MB.'); }
    if (bytes.length % 32768 === 512) { bytes = new Uint8Array(bytes.buffer.slice(bytes.byteOffset + 512, bytes.byteOffset + bytes.byteLength)); }
    var valid = false;
    [0x7fc0, 0xffc0, 0x40ffc0].forEach(function (offset) {
      if (offset + 64 <= bytes.length) {
        var reset = bytes[offset + 60] | (bytes[offset + 61] << 8);
        var mode = bytes[offset + 21] & 15;
        if (reset >= 0x8000 && mode <= 5) { valid = true; }
      }
    });
    if (!valid) { throw new Error('No reconozco un ROM de SNES válido. Usa el archivo .sfc o .smc descomprimido.'); }
    return bytes;
  }
  function prepare(buffer, name, isDemo, restored) {
    var bytes = validate(new Uint8Array(buffer));
    pause(false);
    loaded = false;
    rom = bytes;
    gameName = name;
    gameKey = fingerprint(bytes);
    demo = !!isDemo;
    saved = null;
    $('game-title').textContent = demo ? 'Prueba de pantalla y controles' : name.replace(/\.(sfc|smc)$/i, '');
    $('empty-heading').textContent = demo ? 'Una pequeña prueba de verdad.' : 'Tu juego está listo.';
    $('empty-description').textContent = demo ? 'Pulsa B o las direcciones: el color cambiará.' : name + ' · ' + (bytes.length / 1048576).toFixed(2) + ' MB';
    $('screen-empty').hidden = false;
    $('pause-overlay').hidden = true;
    $('screen').classList.remove('playing');
    $('play-button').hidden = false;
    $('play-button').disabled = !ready;
    $('power-light').classList.remove('on');
    $('save-button').disabled = true;
    $('pause-button').disabled = true;
    $('restore-button').disabled = true;
    $('reset-button').disabled = true;
    $('export-button').disabled = true;
    $('delete-button').hidden = false;
    status(ready ? (restored ? 'Encontré tu último juego. Pulsa Jugar para volver.' : 'ROM listo. Pulsa Jugar para empezar.') : 'ROM listo. Preparando el núcleo…');
    if (!demo) {
      getRecord('save-' + gameKey, function (record) {
        if (record && record.gameKey === gameKey) { saved = record; $('restore-button').disabled = !loaded; }
      });
      if (!restored) {
        putRecord('last-rom', {bytes:bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength),name:name}, function (ok) {
          if (!ok) { status('ROM listo. Safari no permitió conservarlo; tendrás que abrirlo otra vez al volver.'); }
        });
      }
    }
  }
  function readFile(input, callback, limit) {
    var file = input.files && input.files[0];
    if (!file) { return; }
    if (file.size > limit) { status('Ese archivo es demasiado grande para esta consola.', true); input.value = ''; return; }
    var reader = new FileReader();
    reader.onload = function () {
      try { callback(reader.result, file.name); } catch (e) { status(e.message || 'No pude abrir el archivo.', true); }
      input.value = '';
    };
    reader.onerror = function () { status('No pude leer el archivo. Comprueba que esté descargado en el iPad.', true); input.value = ''; };
    reader.readAsArrayBuffer(file);
  }
  $('rom-input').addEventListener('change', function () {
    if (this.files[0] && !/\.(sfc|smc)$/i.test(this.files[0].name)) { status('Elige un archivo .sfc o .smc. Primero descomprime el ZIP.', true); this.value = ''; return; }
    readFile(this, function (buffer, name) { prepare(buffer, name, false, false); }, 8389120);
  });
  $('test-button').addEventListener('click', function () {
    try { prepare(window.SedaDiagnostic(), 'Prueba Seda.sfc', true, false); start(); } catch (e) { status('La prueba no pudo arrancar: ' + e.message, true); }
  });

  function unlockAudio(chirp) {
    try {
      if (!audio || audio.state === 'closed') {
        var Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) { throw new Error('Audio no disponible'); }
        audio = new Audio();
        gain = audio.createGain();
        gain.gain.value = sound ? 0.65 : 0;
        gain.connect(audio.destination);
        audioNext = 0;
      }
      if (audio.state === 'suspended') { var promise = audio.resume(); if (promise && promise.catch) { promise.catch(function () {}); } }
      if (chirp) {
        var oscillator = audio.createOscillator(), volume = audio.createGain();
        oscillator.frequency.value = 523.25;
        volume.gain.setValueAtTime(0.10, audio.currentTime);
        volume.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.16);
        oscillator.connect(volume); volume.connect(audio.destination);
        oscillator.start(); oscillator.stop(audio.currentTime + 0.18);
      }
      return true;
    } catch (e) {
      sound = false;
      $('sound-label').textContent = 'Sin audio';
      if (chirp) { toast('El audio no está disponible. Puedes jugar en silencio.'); }
      return false;
    }
  }
  function pushAudio() {
    if (!audio || audio.state !== 'running' || !sound) { return; }
    if (audioNext < audio.currentTime || audioNext > audio.currentTime + 0.20) { audioNext = audio.currentTime + 0.05; }
    if (audioNext - audio.currentTime > 0.09) { return; }
    var ptr = core._getSoundBuffer();
    if (!ptr) { return; }
    var samples = new Float32Array(core.HEAPF32.buffer, ptr, 4096);
    var buffer = audio.createBuffer(2, 2048, 36000);
    buffer.getChannelData(0).set(samples.subarray(0,2048));
    buffer.getChannelData(1).set(samples.subarray(2048,4096));
    var source = audio.createBufferSource();
    source.buffer = buffer; source.connect(gain); source.start(audioNext);
    audioNext += buffer.duration;
  }
  $('sound-button').addEventListener('click', function () {
    sound = !sound;
    if (sound) { unlockAudio(demo || !loaded); }
    if (gain) { gain.gain.value = sound && running ? 0.65 : 0; }
    audioNext = 0;
    $('sound-label').textContent = sound ? 'Con sonido' : 'Sin sonido';
    $('sound-button').setAttribute('aria-label', sound ? 'Desactivar sonido' : 'Activar sonido');
    toast(sound ? 'Sonido activado. Toca otra vez para silenciar.' : 'Sonido desactivado.');
  });
  $('sound-label').textContent = 'Sin sonido';

  function start() {
    if (!ready || !rom) { status('Primero elige tu ROM, o pulsa Probar sin ROM.'); return; }
    try {
      unlockAudio(false);
      var ptr = core._my_malloc(rom.length);
      if (!ptr) { throw new Error('No hay memoria suficiente.'); }
      try { core.HEAPU8.set(rom, ptr); core._startWithRom(ptr, rom.length, 36000); }
      finally { core._my_free(ptr); }
      loaded = true;
      inputs = {}; keyboard = {}; padMask = 0;
      $('screen').classList.add('playing');
      $('screen-empty').hidden = true;
      $('power-light').classList.add('on');
      $('save-button').disabled = false;
      $('pause-button').disabled = false;
      $('reset-button').disabled = false;
      $('export-button').disabled = false;
      $('restore-button').disabled = !saved;
      resume();
      status(demo ? 'Prueba SNES: B = verde · A = rojo · cruceta = otros colores. ♪ prueba el sonido.' : 'Jugando · Tu juego y tus partidas permanecen en este navegador.');
    } catch (e) { fail(e); }
  }
  $('play-button').addEventListener('click', start);
  function fail(error) {
    running = false;
    cancelAnimationFrame(frameHandle);
    if (gain) { gain.gain.value = 0; }
    $('pause-button').disabled = true;
    $('save-button').disabled = true;
    $('restore-button').disabled = true;
    $('power-light').classList.remove('on');
    status('El núcleo se detuvo: ' + (error.message || String(error)) + '. Puedes recargar y probar otro ROM.', true);
  }
  function tick(timestamp) {
    if (!running) { return; }
    frameHandle = requestAnimationFrame(tick);
    if (!lastFrame) { lastFrame = timestamp - 17; }
    var elapsed = timestamp - lastFrame;
    if (elapsed < 15.7) { return; }
    lastFrame = elapsed > 67 ? timestamp : lastFrame + 1000/60.0988;
    try {
      core._setJoypadInput(padMask);
      core._setJoypadInput2(0);
      core._mainLoop();
      frameCounter++;
      if (!$('economy-mode').checked || frameCounter % 2 === 0) {
        var ptr = core._getScreenBuffer();
        image.data.set(new Uint8Array(core.HEAPU8.buffer, ptr, 512*448*4));
        context.putImageData(image, 0, 0);
      }
      pushAudio();
      perfFrames++;
      if (!perfStart) { perfStart = timestamp; }
      if (timestamp - perfStart >= 2000) {
        $('performance').textContent = Math.round(perfFrames*1000/(timestamp-perfStart)) + ' fps';
        perfStart = timestamp; perfFrames = 0;
      }
    } catch (e) { fail(e); }
  }
  function resume() {
    if (!loaded) { return; }
    unlockAudio(false);
    if (running) { return; }
    running = true;
    lastFrame = 0; perfStart = 0; perfFrames = 0; audioNext = 0;
    if (gain) { gain.gain.value = sound ? 0.65 : 0; }
    $('pause-overlay').hidden = true;
    $('pause-button').textContent = 'Ⅱ Pausa';
    cancelAnimationFrame(frameHandle);
    frameHandle = requestAnimationFrame(tick);
  }
  function pause(autoSave) {
    if (!loaded) { return; }
    running = false;
    cancelAnimationFrame(frameHandle);
    inputs = {}; keyboard = {}; updateInput();
    if (gain) { gain.gain.value = 0; }
    $('pause-overlay').hidden = false;
    $('pause-button').textContent = '▶ Seguir';
    if (autoSave && !demo) { save(false); }
  }
  $('pause-button').addEventListener('click', function () { if (running) { pause(true); } else { resume(); } });
  $('resume-button').addEventListener('click', resume);
  document.addEventListener('visibilitychange', function () { if (document.hidden && running) { pause(true); } });
  window.addEventListener('blur', function () { if (running) { pause(true); } else { inputs = {}; keyboard = {}; updateInput(); } });
  window.addEventListener('pagehide', function () { if (loaded && !demo) { save(false); } });
  $('reset-button').addEventListener('click', function () {
    if (loaded && window.confirm('¿Volver al inicio del juego? Tu punto guardado se conservará.')) { start(); }
  });

  function snapshot() {
    var size = core._getStateSaveSize(), ptr = core._saveState();
    if (!size || !ptr) { throw new Error('Este juego no permitió crear una partida.'); }
    try { return new Uint8Array(new Uint8Array(core.HEAPU8.buffer,ptr,size)); }
    finally { core._my_free(ptr); }
  }
  function save(notify) {
    if (!loaded) { return; }
    try {
      var record = {bytes:snapshot().buffer,gameKey:gameKey,name:gameName,time:Date.now()};
      saved = record;
      $('restore-button').disabled = false;
      putRecord('save-' + gameKey, record, function (ok) {
        if (notify) { toast(ok ? 'Partida guardada en este dispositivo.' : 'Guardada solo en memoria. Exporta una copia antes de salir.'); }
      });
    } catch (e) { if (notify) { status('No pude guardar: ' + e.message, true); } }
  }
  $('save-button').addEventListener('click', function () { save(true); });
  function restore(record) {
    if (!loaded || !record) { return; }
    if (record.gameKey !== gameKey) { throw new Error('Esa partida corresponde a otro ROM.'); }
    var bytes = new Uint8Array(record.bytes), ptr = core._my_malloc(bytes.length);
    try { core.HEAPU8.set(bytes,ptr); core._loadState(ptr,bytes.length); }
    finally { core._my_free(ptr); }
    audioNext = 0;
    resume(); toast('De vuelta en tu partida.');
  }
  $('restore-button').addEventListener('click', function () { try { restore(saved); } catch (e) { status(e.message,true); } });
  $('export-button').addEventListener('click', function () {
    if (!loaded) { return; }
    try {
      var record = {format:'seda-state-v1',gameKey:gameKey,name:gameName,bytes:Array.prototype.slice.call(snapshot())};
      var blob = new Blob([JSON.stringify(record)], {type:'application/octet-stream'});
      var url = URL.createObjectURL(blob), a = document.createElement('a');
      a.href = url; a.download = gameName.replace(/\.(sfc|smc)$/i,'') + '.seda';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); },60000);
      toast('Si Safari abre la copia, usa Compartir para conservarla.');
    } catch (e) { status('No pude exportar: ' + e.message, true); }
  });
  $('state-input').addEventListener('change', function () {
    if (!loaded) { status('Primero abre el ROM y pulsa Jugar.',true); this.value=''; return; }
    readFile(this, function (buffer) {
      var text = '', bytes = new Uint8Array(buffer);
      for (var i=0; i<bytes.length; i++) { text += String.fromCharCode(bytes[i]); }
      var record = JSON.parse(text);
      if (record.format !== 'seda-state-v1' || !Array.isArray(record.bytes) || record.bytes.length>2000000 || !record.bytes.every(function (n) { return typeof n==='number' && n>=0 && n<=255 && Math.floor(n)===n; })) { throw new Error('La copia no es una partida de Seda válida.'); }
      record.bytes = new Uint8Array(record.bytes).buffer;
      restore(record); saved = record; $('restore-button').disabled=false;
      putRecord('save-'+gameKey,record);
      closeHelp();
    }, 12000000);
  });
  $('delete-button').addEventListener('click', function () {
    if (!window.confirm('¿Borrar los ROMs y partidas de Seda guardados en este navegador?')) { return; }
    pause(false);
    if(nativeAvailable()){nativeRequest('clear',null,null,function(value,ok){if(ok){window.location.reload();}else{status('No pude borrar los datos.',true);}});return;}
    if (db) {
      var tx = db.transaction('data','readwrite'); tx.objectStore('data').clear();
      tx.oncomplete = function () { window.location.reload(); };
      tx.onerror = function () { status('No pude borrar los datos. Revisa el almacenamiento de Safari.',true); };
    } else { window.location.reload(); }
  });

  function updateInput() {
    var mask = 0, id;
    for (id in inputs) { if (Object.prototype.hasOwnProperty.call(inputs,id)) { mask |= inputs[id]; } }
    for (id in keyboard) { if (Object.prototype.hasOwnProperty.call(keyboard,id)) { mask |= keyboard[id]; } }
    padMask = mask;
    var buttons = document.querySelectorAll('[data-key]');
    for (var i=0; i<buttons.length; i++) {
      var active = !!(mask & bits[buttons[i].getAttribute('data-key')]);
      buttons[i].classList.toggle('pressed',active);
      buttons[i].setAttribute('aria-pressed',String(active));
    }
    $('dpad').classList.toggle('pressed',!!(mask & 3840));
  }
  function inputAt(x,y,target) {
    var d=$('dpad'), r=d.getBoundingClientRect();
    if (x>=r.left && x<=r.right && y>=r.top && y<=r.bottom) {
      var horizontal = (x-r.left)/r.width-0.5, vertical=(y-r.top)/r.height-0.5, mask=0;
      if (horizontal < -0.16) { mask |= bits.left; } else if (horizontal > 0.16) { mask |= bits.right; }
      if (vertical < -0.16) { mask |= bits.up; } else if (vertical > 0.16) { mask |= bits.down; }
      return mask;
    }
    var node=target || document.elementFromPoint(x,y);
    while (node && node !== document.body) {
      if (node.getAttribute && node.getAttribute('data-key')) { return bits[node.getAttribute('data-key')] || 0; }
      node=node.parentNode;
    }
    return 0;
  }
  document.addEventListener('touchstart', function (event) {
    var handled=false;
    for(var i=0; i<event.changedTouches.length; i++) {
      var touch=event.changedTouches[i], mask=inputAt(touch.clientX,touch.clientY,touch.target);
      if(mask) { inputs['touch-'+touch.identifier]=mask; handled=true; }
    }
    if(handled) { event.preventDefault(); lastTouch=Date.now(); updateInput(); }
  }, {passive:false});
  document.addEventListener('touchmove', function (event) {
    var handled=false;
    for(var i=0; i<event.changedTouches.length; i++) {
      var touch=event.changedTouches[i], id='touch-'+touch.identifier;
      if(Object.prototype.hasOwnProperty.call(inputs,id)) { inputs[id]=inputAt(touch.clientX,touch.clientY,null); handled=true; }
    }
    if(handled) { event.preventDefault(); updateInput(); }
  }, {passive:false});
  function touchEnd(event) {
    var handled=false;
    for(var i=0; i<event.changedTouches.length; i++) {
      var id='touch-'+event.changedTouches[i].identifier;
      if(Object.prototype.hasOwnProperty.call(inputs,id)) { delete inputs[id]; handled=true; }
    }
    if(handled) { event.preventDefault(); updateInput(); }
  }
  document.addEventListener('touchend',touchEnd,{passive:false});
  document.addEventListener('touchcancel',touchEnd,{passive:false});
  document.addEventListener('mousedown',function (event) {
    if(Date.now()-lastTouch<800 || event.button!==0) { return; }
    var mask=inputAt(event.clientX,event.clientY,event.target);
    if(mask) { event.preventDefault(); inputs.mouse=mask; updateInput(); }
  });
  document.addEventListener('mousemove',function (event) { if(Object.prototype.hasOwnProperty.call(inputs,'mouse')) { inputs.mouse=inputAt(event.clientX,event.clientY,null); updateInput(); } });
  document.addEventListener('mouseup',function () { delete inputs.mouse; updateInput(); });
  document.addEventListener('keydown',function (event) {
    if(!$('help-overlay').hidden) { if(event.key==='Escape') { closeHelp(); } return; }
    if(event.key==='Escape' && loaded) { event.preventDefault(); if(running) { pause(true); } else { resume(); } return; }
    var key=keys[event.code] || keyCodes[event.keyCode];
    if(key && loaded) { event.preventDefault(); keyboard[event.code || event.keyCode]=bits[key]; updateInput(); }
  });
  document.addEventListener('keyup',function (event) { delete keyboard[event.code || event.keyCode]; updateInput(); });
  var helpFocus = null;
  $('about-button').addEventListener('click',function () { helpFocus=document.activeElement; if(running) { pause(true); } $('help-overlay').hidden=false; $('close-help').focus(); });
  function closeHelp() { $('help-overlay').hidden=true; if(helpFocus) { helpFocus.focus(); } }
  $('close-help').addEventListener('click',closeHelp);
  $('help-overlay').addEventListener('click',function (event) { if(event.target===this) { closeHelp(); } });
  $('expand-button').addEventListener('click',function () {
    document.body.classList.toggle('expanded');
    $('expand-button').setAttribute('aria-label',document.body.classList.contains('expanded') ? 'Volver al tamaño normal' : 'Ampliar consola');
    window.scrollTo(0,0); height();
  });
  var tries=0;
  function waitForCore() {
    core=window.SedaCore;
    if(core && core.calledRun && core._startWithRom) {
      ready=true;
      $('play-button').disabled=false;
      status(rom ? 'Tu juego está listo. Pulsa Jugar.' : 'Lista para jugar · Abre tu ROM o prueba los controles.');
      openDatabase();
      return;
    }
    tries++;
    if(tries>200) { status('Safari no pudo preparar el núcleo. Recarga la página para intentarlo de nuevo.',true); return; }
    setTimeout(waitForCore,100);
  }
  waitForCore();
  if('serviceWorker' in navigator && location.protocol==='https:') { navigator.serviceWorker.register('sw.js').catch(function () {}); }
  // Read-only diagnostics for reproducible core/input verification.
  window.SedaDiagnostics = function () { return {ready:ready,loaded:loaded,running:running,demo:demo,input:padMask,frames:frameCounter,gameKey:gameKey,hasSave:!!saved,audioState:audio ? audio.state : 'not-started'}; };
})();
