var CACHE='seda-shell-001';
var ASSETS=['./','index.html','style.css','app.js','diagnostic.js','vendor/snes-core.js','icon.png','icon.svg','manifest.webmanifest'];
self.addEventListener('install',function(event){event.waitUntil(caches.open(CACHE).then(function(cache){return cache.addAll(ASSETS);}));});
self.addEventListener('activate',function(event){event.waitUntil(caches.keys().then(function(keys){return Promise.all(keys.filter(function(key){return key.indexOf('seda-shell-')===0 && key!==CACHE;}).map(function(key){return caches.delete(key);}));}));});
self.addEventListener('fetch',function(event){
 if(event.request.method!=='GET' || new URL(event.request.url).origin!==self.location.origin){return;}
 var path=new URL(event.request.url).pathname;
 if(path!=='/' && !ASSETS.some(function(asset){return '/'+asset===path;})){return;}
 event.respondWith(fetch(event.request).then(function(response){
  if(response.ok && response.type!=='opaqueredirect' && !response.redirected){var copy=response.clone();caches.open(CACHE).then(function(cache){cache.put(event.request,copy);});}
  return response;
 }).catch(function(){return caches.match(event.request);}));
});
