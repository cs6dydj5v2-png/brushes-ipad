#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
: "${DEVELOPER_DIR:=/Applications/Xcode_15.4.app/Contents/Developer}"
export DEVELOPER_DIR
sdk_path="$(xcrun --sdk iphoneos --show-sdk-path)"
mkdir -p build/Payload/Seda.app
app_path="$PWD/build/Payload/Seda.app"
xcrun --sdk iphoneos clang -arch arm64 -isysroot "$sdk_path" -miphoneos-version-min=12.0 -fobjc-arc -O2 main.m -framework UIKit -framework Foundation -framework WebKit -framework CoreGraphics -o "$app_path/Seda"
cp Info.plist "$app_path/Info.plist"
cp web/icon.png "$app_path/AppIcon.png"
cp -R web "$app_path/web"
xcrun ibtool --compile "$app_path/LaunchScreen.storyboardc" --target-device ipad --target-device iphone --minimum-deployment-target 12.0 LaunchScreen.storyboard
plutil -lint "$app_path/Info.plist"
xcrun vtool -show-build "$app_path/Seda"
cd build
zip -q -r Seda-ios12-unsigned.ipa Payload
